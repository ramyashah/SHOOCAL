package ramya.xtremecoders.shoocal_task1;

import android.graphics.drawable.AnimationDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WelcomeScreen extends AppCompatActivity {

    RelativeLayout bg_layout;
    AnimationDrawable animationDrawable;

    Spinner requestby;
    EditText edt_fname,edt_lname,edt_address,edt_phno,edt_restaurantname;
    Button btn_submit;

    private APIService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_screen);

        bg_layout = (RelativeLayout) findViewById(R.id.bg_layout);
        animationDrawable=(AnimationDrawable)bg_layout.getBackground();
        animationDrawable.setEnterFadeDuration(4500);
        animationDrawable.setExitFadeDuration(4500);
        animationDrawable.start();

        init();

        ArrayAdapter<String> req_type_adap = new ArrayAdapter<String>(WelcomeScreen.this, android.R.layout.simple_list_item_1,
                getResources().getStringArray(R.array.request_type));

        req_type_adap.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        requestby.setAdapter(req_type_adap);

        apiService=ApiUtils.getAPIService();

        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submit_data();
            }
        });

    }

    private void init(){

        edt_fname=(EditText)findViewById(R.id.edt_fname);
        edt_lname=(EditText)findViewById(R.id.edt_lname);
        edt_address=(EditText)findViewById(R.id.edt_add);
        edt_phno=(EditText)findViewById(R.id.edt_phno);
        edt_restaurantname=(EditText)findViewById(R.id.edt_restaurantname);
        requestby =(Spinner)findViewById(R.id.spinner_reqtype);
        btn_submit=(Button)findViewById(R.id.btn_submit);
    }

    public void submit_data(){

        if (!validate()) {
            Toast.makeText(getBaseContext(), "Enter Details Properly", Toast.LENGTH_LONG).show();
            return;
        }

        //fetch the details of EditText in String Variable for Validating
        String first_name=edt_fname.getText().toString();
        String last_name=edt_lname.getText().toString();
        String phone=edt_phno.getText().toString();
        String address=edt_phno.getText().toString();
        String restau_name=edt_phno.getText().toString();
        String requestb = "";
        String text = requestby.getSelectedItem().toString();
        if(text=="Owner"){
           requestb = "1";
        }else if(text=="Manager"){
           requestb = "2";
        }else if(text=="Other"){
           requestb = "3";
        }

        Model_Details model_details = new Model_Details();

        model_details.setFirst_name(first_name);
        model_details.setLast_name(last_name);
        model_details.setAddress(address);
        model_details.setPhone(phone);
        model_details.setRestau_name(restau_name);
        model_details.setRequestby(requestb);

        apiService.savedetails(model_details).enqueue(new Callback<Model_Details>() {
            @Override
            public void onResponse(Call<Model_Details> call, Response<Model_Details> response) {

                if(response.isSuccessful()){

                    String res = response.body().toString();
                    Toast.makeText(getBaseContext(),"" + res, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<Model_Details> call, Throwable t) {
                Toast.makeText(getBaseContext(),"Unable to Submit", Toast.LENGTH_LONG).show();
            }
        });
    }

    //Validate the Data Entered in the Registration Form
    private boolean validate()
    {
        boolean valid = true;

        //fetch the details of EditText in String Variable for Validating
        String first_name=edt_fname.getText().toString();
        String last_name=edt_lname.getText().toString();
        String phone=edt_phno.getText().toString();
        String address=edt_phno.getText().toString();
        String restau_name=edt_phno.getText().toString();

        //First Name must not be left Empty
        if(first_name.isEmpty())
        {
            Toast.makeText(this,"Enter First Name",Toast.LENGTH_SHORT).show();
            return false;
        }
        else
        {
            valid=true;
        }

        //last Name must not be left Empty
        if(last_name.isEmpty())
        {
            Toast.makeText(this,"Enter Last Name",Toast.LENGTH_SHORT).show();
            return false;
        }
        else
        {
            valid=true;
        }

        //Phone Number must not be left Empty
        if(phone.isEmpty())
        {
            Toast.makeText(this,"Enter Phone Number",Toast.LENGTH_SHORT).show();
            return false;
        }
        else
        {
            valid=true;
        }

        //Address must not be left Empty
        if(address.isEmpty())
        {
            Toast.makeText(this,"Enter Address",Toast.LENGTH_SHORT).show();
            return false;
        }
        else
        {
            valid=true;
        }

        //Restaurant Name must not be left Empty
        if(restau_name.isEmpty())
        {
            Toast.makeText(this,"Enter Restaurant Name",Toast.LENGTH_SHORT).show();
            return false;
        }
        else
        {
            valid=true;
        }

        return valid;
    }
}
