package ramya.xtremecoders.shoocal_task1;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * Created by SHAH on 29/07/2018.
 */

public class APIService {

    @POST("/democalltesting")
    @FormUrlEncoded
    Call<Model_Details> savedetails(@Body Model_Details model_details) {
        return null;
    }

    /*Call<Model_Details> savedetails(@Field("first_name") String first_name,
                                    @Field("last_name") String last_name,
                                    @Field("phone") String phone,
                                    @Field("address") String address,
                                    @Field("restau_name") String restau_name,
                                    @Field("requestby") String requestby);*/
}
