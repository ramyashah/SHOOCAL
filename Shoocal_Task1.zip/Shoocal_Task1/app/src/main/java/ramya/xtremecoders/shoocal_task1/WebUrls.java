package ramya.xtremecoders.shoocal_task1;

/**
 * Created by SHAH on 29/07/2018.
 */

public class WebUrls {

    public static final String BASE_URL = "http://api.shoocal.com/test/manager/democalltesting";
}
