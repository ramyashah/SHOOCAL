package ramya.xtremecoders.shoocal_task1;

/**
 * Created by SHAH on 29/07/2018.
 */

public class ApiUtils {

    private ApiUtils() {}

    public static final String BASE_URL = "http://api.shoocal.com/test/manager/";

    public static APIService getAPIService() {

        return RetrofitClient.getClient(BASE_URL).create(APIService.class);
    }
}
